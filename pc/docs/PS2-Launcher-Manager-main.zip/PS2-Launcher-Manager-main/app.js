import { readIsoGame, parseUlCfg, expectedUlPartNames } from "./iso-reader.js";

const ARTWORK_ORIGIN = "https://ps2api.appdadz.com";
const LOCAL_HOST = location.hostname === "localhost" || location.hostname === "127.0.0.1";

function directArtworkUrl(type, id) {
  return type === "cover" ?
    `${ARTWORK_ORIGIN}/art/${encodeURIComponent(id)}_COV.jpg` :
    `${ARTWORK_ORIGIN}/icons/${encodeURIComponent(id)}_LOGO.png`;
}

async function fetchArtwork(type, id, options = {}) {
  /* Older localhost builds enforce connect-src 'self' and expose the fixed
   * artwork proxy. Use it first so even a still-running old server works.
   * GitHub Pages has no backend and downloads from the HTTPS CORS endpoint. */
  if (LOCAL_HOST) {
    const localResponse = await fetch(`/api/artwork/${type}/${encodeURIComponent(id)}`, options);
    if (localResponse.status !== 404) return localResponse;
    try {
      const payload = await localResponse.clone().json();
      if (payload.id === id && payload.type === type) return localResponse;
    } catch {
      /* The current static server has no proxy; continue to direct HTTPS. */
    }
  }
  return fetch(directArtworkUrl(type, id), { ...options, mode: "cors" });
}

const elements = {
  selectDrive: document.querySelector("#selectDriveButton"),
  rescan: document.querySelector("#rescanButton"),
  workspace: document.querySelector("#workspace"),
  driveName: document.querySelector("#driveName"),
  gameCount: document.querySelector("#gameCount"),
  isoCount: document.querySelector("#isoCount"),
  ulCount: document.querySelector("#ulCount"),
  unresolvedCount: document.querySelector("#unresolvedCount"),
  search: document.querySelector("#searchInput"),
  missing: document.querySelector("#downloadMissingButton"),
  all: document.querySelector("#downloadAllButton"),
  cancel: document.querySelector("#cancelButton"),
  progressPanel: document.querySelector("#progressPanel"),
  progressTitle: document.querySelector("#progressTitle"),
  progressNumbers: document.querySelector("#progressNumbers"),
  progressFill: document.querySelector("#progressFill"),
  progressDetail: document.querySelector("#progressDetail"),
  notice: document.querySelector("#notice"),
  rows: document.querySelector("#gameRows"),
  empty: document.querySelector("#emptyState")
};

let driveHandle = null;
let games = [];
let operationController = null;
let busy = false;

const STATUS_LABELS = {
  checking: "Checking",
  ready: "Ready",
  missing: "Missing",
  downloading: "Downloading",
  unavailable: "Unavailable",
  failed: "Failed",
  unresolved: "No disc ID"
};

async function loadFeaturedArtwork() {
  const covers = [...document.querySelectorAll("img[data-artwork-id]")];
  const coversById = new Map();
  for (const image of covers) {
    const matchingImages = coversById.get(image.dataset.artworkId) || [];
    matchingImages.push(image);
    coversById.set(image.dataset.artworkId, matchingImages);
  }

  await Promise.allSettled([...coversById].map(async ([id, images]) => {
    const response = await fetchArtwork("cover", id, { cache: "force-cache" });
    if (!response.ok) throw new Error(`Featured artwork unavailable: ${id}`);
    const blob = await response.blob();
    if (blob.size < 1024 || !blob.type.startsWith("image/")) throw new Error(`Invalid featured artwork: ${id}`);
    const objectUrl = URL.createObjectURL(blob);
    await Promise.all(images.map(image => new Promise(resolve => {
      image.addEventListener("load", resolve, { once: true });
      image.addEventListener("error", resolve, { once: true });
      image.src = objectUrl;
    })));
    URL.revokeObjectURL(objectUrl);
  }));
}

function setNotice(message = "", error = false) {
  elements.notice.hidden = !message;
  elements.notice.textContent = message;
  elements.notice.classList.toggle("error", error);
}

function setProgress(title, current, total, detail) {
  elements.progressPanel.hidden = false;
  elements.progressTitle.textContent = title;
  elements.progressNumbers.textContent = `${current} / ${total}`;
  elements.progressFill.style.width = `${total ? Math.round(current * 100 / total) : 0}%`;
  elements.progressDetail.textContent = detail;
}

function hideProgress() {
  elements.progressPanel.hidden = true;
  elements.progressFill.style.width = "0%";
}

function setBusy(value, cancellable = false) {
  busy = value;
  elements.selectDrive.disabled = value;
  elements.rescan.disabled = value || !driveHandle;
  elements.missing.disabled = value || !games.some(game => game.id);
  elements.all.disabled = value || !games.some(game => game.id);
  elements.cancel.hidden = !value || !cancellable;
}

function cleanIsoTitle(filename) {
  return filename.replace(/\.iso$/i, "").trim() || "PS2 game";
}

async function getEntries(handle) {
  const entries = [];
  for await (const [name, entry] of handle.entries()) entries.push({ name, entry });
  return entries;
}

function findEntry(entries, name, kind) {
  const wanted = name.toUpperCase();
  return entries.find(item => item.name.toUpperCase() === wanted && (!kind || item.entry.kind === kind)) || null;
}

async function runPool(items, concurrency, worker) {
  let cursor = 0;
  async function consume() {
    while (cursor < items.length) {
      const index = cursor++;
      await worker(items[index], index);
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, consume));
}

async function validImageFile(file, type) {
  if (!file || file.size < 1024) return false;
  const head = new Uint8Array(await file.slice(0, 8).arrayBuffer());
  const jpeg = head[0] === 0xff && head[1] === 0xd8;
  const png = head.length >= 8 && head[0] === 0x89 && head[1] === 0x50 && head[2] === 0x4e && head[3] === 0x47;
  /* The launcher accepts both extensions for both asset folders. */
  return type === "cover" ? jpeg || png : png || jpeg;
}

async function artworkDirectoryState(rootEntries, directoryName) {
  const match = findEntry(rootEntries, directoryName, "directory");
  if (!match) return { handle: null, files: new Map() };
  const files = new Map();
  for await (const [name, entry] of match.entry.entries()) {
    if (entry.kind === "file") files.set(name.toUpperCase(), entry);
  }
  return { handle: match.entry, files };
}

async function checkArtwork(rootEntries) {
  const art = await artworkDirectoryState(rootEntries, "ART");
  const icons = await artworkDirectoryState(rootEntries, "ICONS");
  const identifiable = games.filter(game => game.id);
  let completed = 0;
  setProgress("Checking existing artwork", 0, identifiable.length, "Reading ART and ICONS folders…");

  await runPool(identifiable, 5, async game => {
    const coverEntry = art.files.get(`${game.id}_COV.JPG`) || art.files.get(`${game.id}_COV.PNG`);
    const logoEntry = icons.files.get(`${game.id}_LOGO.PNG`) || icons.files.get(`${game.id}_LOGO.JPG`);
    game.coverStatus = coverEntry && await validImageFile(await coverEntry.getFile(), "cover") ? "ready" : "missing";
    game.logoStatus = logoEntry && await validImageFile(await logoEntry.getFile(), "logo") ? "ready" : "missing";
    completed++;
    setProgress("Checking existing artwork", completed, identifiable.length, game.title);
  });
}

async function scanDrive() {
  if (!driveHandle || busy) return;
  setBusy(true);
  setNotice();
  games = [];
  renderGames();

  try {
    const rootEntries = await getEntries(driveHandle);
    const rootFileNames = new Set(rootEntries.filter(item => item.entry.kind === "file").map(item => item.name.toLowerCase()));
    const isoFiles = [];

    for (const directoryName of ["DVD", "CD"]) {
      const directory = findEntry(rootEntries, directoryName, "directory");
      if (!directory) continue;
      for await (const [name, entry] of directory.entry.entries()) {
        if (entry.kind === "file" && name.toLowerCase().endsWith(".iso")) {
          isoFiles.push({ name, handle: entry, directory: directoryName });
        }
      }
    }

    const ulCfg = findEntry(rootEntries, "ul.cfg", "file");
    const totalScanItems = isoFiles.length + (ulCfg ? 1 : 0);
    let scanned = 0;
    setProgress("Reading game metadata", 0, totalScanItems, "Looking for DVD, CD and ul.cfg games…");

    if (ulCfg) {
      const ulGames = await parseUlCfg(await ulCfg.entry.getFile());
      for (const ulGame of ulGames) {
        const expectedParts = expectedUlPartNames(ulGame);
        const missingParts = expectedParts.filter(name => !rootFileNames.has(name.toLowerCase()));
        games.push({
          uid: `ul-${ulGame.record}-${ulGame.id || "unknown"}`,
          title: ulGame.title,
          id: ulGame.id,
          format: "UL",
          path: `ul.cfg record ${ulGame.record + 1}${missingParts.length ? ` · ${missingParts.length}/${ulGame.parts} split parts not found` : ` · ${ulGame.parts} parts`}`,
          error: ulGame.error,
          coverStatus: ulGame.id ? "checking" : "unresolved",
          logoStatus: ulGame.id ? "checking" : "unresolved"
        });
      }
      scanned++;
      setProgress("Reading game metadata", scanned, totalScanItems, `${ulGames.length} UL games found`);
    }

    await runPool(isoFiles, 2, async isoItem => {
      let metadata = null;
      let error = null;
      try {
        metadata = await readIsoGame(await isoItem.handle.getFile());
      } catch (reason) {
        error = reason instanceof Error ? reason.message : String(reason);
      }

      games.push({
        uid: `iso-${isoItem.directory}-${isoItem.name}`,
        title: cleanIsoTitle(isoItem.name),
        id: metadata?.id || null,
        format: "ISO",
        path: `${isoItem.directory}/${isoItem.name}`,
        error,
        coverStatus: metadata?.id ? "checking" : "unresolved",
        logoStatus: metadata?.id ? "checking" : "unresolved"
      });
      scanned++;
      setProgress("Reading game metadata", scanned, totalScanItems, `${isoItem.directory}/${isoItem.name}`);
      renderGames();
    });

    games.sort((a, b) => a.title.localeCompare(b.title, undefined, { sensitivity: "base" }));
    await checkArtwork(rootEntries);
    updateSummary();
    renderGames();
    const resolved = games.filter(game => game.id).length;
    setNotice(`${resolved} game${resolved === 1 ? "" : "s"} identified from disc metadata. No game filename was used as a disc ID.`);
  } catch (reason) {
    setNotice(reason instanceof Error ? reason.message : String(reason), true);
  } finally {
    hideProgress();
    setBusy(false);
    renderGames();
  }
}

function createStatus(status) {
  const span = document.createElement("span");
  span.className = `status ${status}`;
  span.textContent = STATUS_LABELS[status] || status;
  return span;
}

function renderGames() {
  const query = elements.search.value.trim().toLowerCase();
  const visible = games.filter(game => !query || game.title.toLowerCase().includes(query) || (game.id || "").toLowerCase().includes(query));
  elements.rows.replaceChildren();

  for (const game of visible) {
    const row = document.createElement("tr");
    const titleCell = document.createElement("td");
    const title = document.createElement("span");
    const path = document.createElement("span");
    title.className = "game-title";
    title.textContent = game.title;
    path.className = "game-path";
    path.textContent = game.error ? `${game.path} · ${game.error}` : game.path;
    titleCell.append(title, path);

    const idCell = document.createElement("td");
    idCell.className = "disc-id";
    idCell.textContent = game.id || "UNRESOLVED";
    const formatCell = document.createElement("td");
    const format = document.createElement("span");
    format.className = "format";
    format.textContent = game.format;
    formatCell.append(format);
    const coverCell = document.createElement("td");
    coverCell.append(createStatus(game.coverStatus));
    const logoCell = document.createElement("td");
    logoCell.append(createStatus(game.logoStatus));
    row.append(titleCell, idCell, formatCell, coverCell, logoCell);
    elements.rows.append(row);
  }

  elements.empty.hidden = visible.length > 0 || busy;
  if (!visible.length && !busy) {
    const emptyTitle = elements.empty.querySelector("h3");
    const emptyDetail = elements.empty.querySelector("p");
    if (games.length) {
      emptyTitle.textContent = "No games match your search";
      emptyDetail.textContent = "Try another title or disc ID.";
    } else {
      emptyTitle.textContent = "No supported games found";
      emptyDetail.textContent = "No ISO or UL-format games were detected on this drive.";
    }
  }
  updateSummary();
}

function updateSummary() {
  elements.gameCount.textContent = games.length;
  elements.isoCount.textContent = games.filter(game => game.format === "ISO").length;
  elements.ulCount.textContent = games.filter(game => game.format === "UL").length;
  elements.unresolvedCount.textContent = games.filter(game => !game.id).length;
}

function updateStatusForId(id, type, status) {
  for (const game of games) {
    if (game.id === id) game[type === "cover" ? "coverStatus" : "logoStatus"] = status;
  }
  renderGames();
}

function validateDownloadedAsset(bytes, type) {
  if (bytes.byteLength < 1024) return false;
  const view = new Uint8Array(bytes, 0, Math.min(bytes.byteLength, 8));
  if (type === "cover") return view[0] === 0xff && view[1] === 0xd8;
  return view[0] === 0x89 && view[1] === 0x50 && view[2] === 0x4e && view[3] === 0x47;
}

async function writeValidatedFile(directory, filename, bytes) {
  const partialName = `${filename}.part`;
  const partial = await directory.getFileHandle(partialName, { create: true });
  const partialWriter = await partial.createWritable();
  await partialWriter.write(bytes);
  await partialWriter.close();

  const final = await directory.getFileHandle(filename, { create: true });
  const finalWriter = await final.createWritable();
  await finalWriter.write(bytes);
  await finalWriter.close();
  await directory.removeEntry(partialName).catch(() => {});
}

async function downloadJob(job, directories, signal) {
  updateStatusForId(job.id, job.type, "downloading");
  const response = await fetchArtwork(job.type, job.id, { signal, cache: "no-store" });
  if (response.status === 404) {
    updateStatusForId(job.id, job.type, "unavailable");
    return "unavailable";
  }
  if (!response.ok) {
    updateStatusForId(job.id, job.type, "failed");
    throw new Error(`${job.id} ${job.type}: server returned ${response.status}`);
  }

  const bytes = await response.arrayBuffer();
  if (!validateDownloadedAsset(bytes, job.type)) {
    updateStatusForId(job.id, job.type, "failed");
    throw new Error(`${job.id} ${job.type}: invalid image received`);
  }

  const directory = job.type === "cover" ? directories.art : directories.icons;
  const filename = job.type === "cover" ? `${job.id}_COV.jpg` : `${job.id}_LOGO.png`;
  await writeValidatedFile(directory, filename, bytes);
  updateStatusForId(job.id, job.type, "ready");
  return "ready";
}

async function downloadArtwork(mode) {
  if (!driveHandle || busy) return;
  const ids = [...new Set(games.filter(game => game.id).map(game => game.id))];
  const jobs = [];
  for (const id of ids) {
    const representative = games.find(game => game.id === id);
    if (mode === "all" || representative.coverStatus !== "ready") jobs.push({ id, type: "cover" });
    if (mode === "all" || representative.logoStatus !== "ready") jobs.push({ id, type: "logo" });
  }

  if (!jobs.length) {
    setNotice("All detected games already have valid covers and logos.");
    return;
  }

  setBusy(true, true);
  setNotice();
  operationController = new AbortController();
  let completed = 0;
  let saved = 0;
  let unavailable = 0;
  let failed = 0;

  try {
    const art = await driveHandle.getDirectoryHandle("ART", { create: true });
    const icons = await driveHandle.getDirectoryHandle("ICONS", { create: true });
    setProgress("Downloading artwork", 0, jobs.length, "Preparing ART and ICONS folders…");

    await runPool(jobs, 3, async job => {
      if (operationController.signal.aborted) return;
      try {
        const result = await downloadJob(job, { art, icons }, operationController.signal);
        if (result === "ready") saved++;
        else unavailable++;
      } catch (reason) {
        if (reason?.name !== "AbortError") {
          failed++;
          updateStatusForId(job.id, job.type, "failed");
        }
      } finally {
        completed++;
        setProgress("Downloading artwork", completed, jobs.length, `${job.id} · ${job.type}`);
      }
    });

    if (operationController.signal.aborted) {
      for (const game of games) {
        if (game.coverStatus === "downloading") game.coverStatus = "missing";
        if (game.logoStatus === "downloading") game.logoStatus = "missing";
      }
      renderGames();
      setNotice("Artwork download cancelled.");
    } else {
      setNotice(`${saved}/${jobs.length} artwork files saved · ${unavailable} unavailable · ${failed} failed${unavailable ? ". Missing artwork can be requested on Instagram @irfanmatheena." : ""}`, failed > 0);
    }
  } catch (reason) {
    setNotice(reason instanceof Error ? reason.message : String(reason), true);
  } finally {
    operationController = null;
    hideProgress();
    setBusy(false);
  }
}

async function selectDrive() {
  if (!("showDirectoryPicker" in window)) {
    setNotice("Direct USB access requires Chrome or Edge on localhost.", true);
    return;
  }

  try {
    const selected = await window.showDirectoryPicker({ mode: "readwrite", id: "ps2-artwork-usb" });
    const permission = await selected.requestPermission({ mode: "readwrite" });
    if (permission !== "granted") throw new Error("Read/write permission was not granted");
    driveHandle = selected;
    const selectedName = (selected.name || "").replace(/[\\/]+$/, "").trim();
    elements.driveName.textContent = selectedName || "PS2 USB drive";
    elements.workspace.hidden = false;
    elements.rescan.disabled = false;
    // Force the newly revealed section into layout before scrolling. Smooth
    // scrolling can be cancelled when the scan immediately updates the page.
    void elements.workspace.offsetHeight;
    elements.workspace.scrollIntoView({ behavior: "auto", block: "start" });
    await scanDrive();
  } catch (reason) {
    if (reason?.name !== "AbortError") setNotice(reason instanceof Error ? reason.message : String(reason), true);
  }
}

elements.selectDrive.addEventListener("click", selectDrive);
elements.rescan.addEventListener("click", scanDrive);
elements.search.addEventListener("input", renderGames);
elements.missing.addEventListener("click", () => downloadArtwork("missing"));
elements.all.addEventListener("click", () => downloadArtwork("all"));
elements.cancel.addEventListener("click", () => operationController?.abort());

if (!("showDirectoryPicker" in window)) {
  elements.selectDrive.disabled = true;
  setNotice("Open this page in the current Chrome or Edge browser to write artwork directly to USB.", true);
}

loadFeaturedArtwork();
