import http from "node:http";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";
import path from "node:path";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number.parseInt(process.env.PORT || "4173", 10);

const STATIC_FILES = new Map([
  ["/", ["index.html", "text/html; charset=utf-8"]],
  ["/index.html", ["index.html", "text/html; charset=utf-8"]],
  ["/styles.css", ["styles.css", "text/css; charset=utf-8"]],
  ["/app.js", ["app.js", "text/javascript; charset=utf-8"]],
  ["/iso-reader.js", ["iso-reader.js", "text/javascript; charset=utf-8"]]
]);

function headers(contentType) {
  return {
    "Content-Type": contentType,
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
    "Cross-Origin-Opener-Policy": "same-origin"
  };
}

function sendJson(response, status, payload) {
  response.writeHead(status, { ...headers("application/json; charset=utf-8"), "Cache-Control": "no-store" });
  response.end(JSON.stringify(payload));
}

export const server = http.createServer(async (request, response) => {
  const url = new URL(request.url || "/", `http://${request.headers.host || "localhost"}`);

  if (request.method !== "GET") {
    sendJson(response, 405, { error: "Method not allowed" });
    return;
  }

  if (url.pathname === "/api/health") {
    sendJson(response, 200, { ok: true, service: "PS2 Artwork Station static server" });
    return;
  }

  const staticFile = STATIC_FILES.get(url.pathname);
  if (!staticFile) {
    sendJson(response, 404, { error: "Not found" });
    return;
  }

  try {
    const body = await readFile(path.join(ROOT, staticFile[0]));
    response.writeHead(200, { ...headers(staticFile[1]), "Cache-Control": "no-cache" });
    response.end(body);
  } catch {
    sendJson(response, 500, { error: "Unable to read application file" });
  }
});

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  server.listen(PORT, "127.0.0.1", () => {
    const address = server.address();
    const activePort = typeof address === "object" && address ? address.port : PORT;
    const url = `http://localhost:${activePort}`;
    console.log(`PS2 Artwork Station: ${url}`);

    if (process.env.OPEN_BROWSER === "1" && process.platform === "win32") {
      const commandPrompt = process.env.ComSpec || "C:\\Windows\\System32\\cmd.exe";
      const browser = spawn(commandPrompt, ["/d", "/c", "start", "", url], {
        detached: true,
        stdio: "ignore",
        windowsHide: true
      });
      browser.unref();
    }
  });
}
