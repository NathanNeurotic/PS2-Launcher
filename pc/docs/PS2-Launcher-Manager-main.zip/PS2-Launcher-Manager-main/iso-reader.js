const ISO_SECTOR_SIZE = 2048;
const ISO_PVD_START = 16;
const ISO_PVD_LIMIT = 32;
const MAX_DIRECTORY_BYTES = 8 * 1024 * 1024;
const MAX_SYSTEM_CNF_BYTES = 64 * 1024;
const UL_RECORD_SIZE = 64;

const textDecoder = new TextDecoder("windows-1252");

function readUint32LE(bytes, offset) {
  return (bytes[offset] |
    (bytes[offset + 1] << 8) |
    (bytes[offset + 2] << 16) |
    (bytes[offset + 3] << 24)) >>> 0;
}

async function readBytes(file, offset, length) {
  if (offset < 0 || length < 0 || offset + length > file.size) {
    throw new Error("Disc image contains an invalid file extent");
  }
  return new Uint8Array(await file.slice(offset, offset + length).arrayBuffer());
}

function decodeFixed(bytes) {
  const zero = bytes.indexOf(0);
  const value = textDecoder.decode(zero >= 0 ? bytes.subarray(0, zero) : bytes);
  return value.replace(/[\u0000\s]+$/g, "").trimStart();
}

export function normalizeDiscId(value) {
  if (!value) return null;
  const match = String(value).toUpperCase().match(/([A-Z]{4})[_-](\d{3})\.(\d{2})/);
  return match ? `${match[1]}_${match[2]}.${match[3]}` : null;
}

function parseDirectoryRecord(bytes, offset) {
  const length = bytes[offset];
  if (length < 34 || offset + length > bytes.length) return null;

  const nameLength = bytes[offset + 32];
  if (33 + nameLength > length) return null;

  const rawName = bytes.subarray(offset + 33, offset + 33 + nameLength);
  let name;
  if (nameLength === 1 && rawName[0] === 0) name = ".";
  else if (nameLength === 1 && rawName[0] === 1) name = "..";
  else name = textDecoder.decode(rawName).replace(/;\d+$/, "");

  return {
    length,
    extent: readUint32LE(bytes, offset + 2),
    size: readUint32LE(bytes, offset + 10),
    directory: (bytes[offset + 25] & 0x02) !== 0,
    name
  };
}

function parseDirectoryEntries(bytes) {
  const entries = [];
  let offset = 0;

  while (offset < bytes.length) {
    const length = bytes[offset];
    if (length === 0) {
      offset = (Math.floor(offset / ISO_SECTOR_SIZE) + 1) * ISO_SECTOR_SIZE;
      continue;
    }

    const record = parseDirectoryRecord(bytes, offset);
    if (!record) break;
    entries.push(record);
    offset += record.length;
  }
  return entries;
}

async function findSystemCnf(file, rootRecord) {
  const queue = [{ ...rootRecord, depth: 0 }];
  const visited = new Set();

  while (queue.length) {
    const directory = queue.shift();
    const key = `${directory.extent}:${directory.size}`;
    if (visited.has(key)) continue;
    visited.add(key);

    if (directory.size > MAX_DIRECTORY_BYTES) {
      throw new Error("ISO directory is unexpectedly large");
    }

    const data = await readBytes(file, directory.extent * ISO_SECTOR_SIZE, directory.size);
    for (const entry of parseDirectoryEntries(data)) {
      const upperName = entry.name.toUpperCase();
      if (!entry.directory && upperName === "SYSTEM.CNF") return entry;
      if (entry.directory && entry.name !== "." && entry.name !== ".." && directory.depth < 5) {
        queue.push({ ...entry, depth: directory.depth + 1 });
      }
    }

    if (visited.size > 256) throw new Error("ISO directory limit exceeded");
  }

  return null;
}

export async function readIsoGame(file) {
  if (!file || file.size < (ISO_PVD_START + 1) * ISO_SECTOR_SIZE) {
    throw new Error("ISO file is too small");
  }

  let rootRecord = null;
  let volumeTitle = "";
  for (let sector = ISO_PVD_START; sector < ISO_PVD_LIMIT; sector++) {
    const descriptor = await readBytes(file, sector * ISO_SECTOR_SIZE, ISO_SECTOR_SIZE);
    const identifier = String.fromCharCode(...descriptor.subarray(1, 6));
    if (identifier !== "CD001") continue;
    if (descriptor[0] === 255) break;
    if (descriptor[0] !== 1) continue;

    volumeTitle = decodeFixed(descriptor.subarray(40, 72));
    rootRecord = parseDirectoryRecord(descriptor, 156);
    break;
  }

  if (!rootRecord) throw new Error("ISO9660 primary volume descriptor was not found");

  const systemCnf = await findSystemCnf(file, rootRecord);
  if (!systemCnf) throw new Error("SYSTEM.CNF was not found inside the ISO");
  if (systemCnf.size <= 0 || systemCnf.size > MAX_SYSTEM_CNF_BYTES) {
    throw new Error("SYSTEM.CNF has an invalid size");
  }

  const cnfBytes = await readBytes(file, systemCnf.extent * ISO_SECTOR_SIZE, systemCnf.size);
  const cnfText = textDecoder.decode(cnfBytes);
  const bootLine = cnfText.match(/^\s*BOOT2?\s*=\s*(.+)$/im);
  const id = normalizeDiscId(bootLine ? bootLine[1] : cnfText);
  if (!id) throw new Error("A valid PS2 disc ID was not found in SYSTEM.CNF");

  return { id, volumeTitle, systemCnf: cnfText };
}

export async function parseUlCfg(file) {
  const bytes = new Uint8Array(await file.arrayBuffer());
  const games = [];

  if (bytes.length < UL_RECORD_SIZE) return games;
  const recordCount = Math.floor(bytes.length / UL_RECORD_SIZE);

  for (let index = 0; index < recordCount; index++) {
    const offset = index * UL_RECORD_SIZE;
    const record = bytes.subarray(offset, offset + UL_RECORD_SIZE);
    const magic = String.fromCharCode(record[32], record[33], record[34]);
    if (magic !== "ul.") continue;

    const title = decodeFixed(record.subarray(0, 32)) || `UL game ${index + 1}`;
    const rawStartup = decodeFixed(record.subarray(35, 47));
    const id = normalizeDiscId(rawStartup);
    games.push({
      title,
      id,
      rawStartup,
      parts: record[47],
      media: record[48],
      record: index,
      error: id ? null : "The ul.cfg record does not contain a valid PS2 disc ID"
    });
  }

  return games;
}

export function usbExtremeCrc32(value) {
  let crc = 0xffffffff;
  const bytes = new TextEncoder().encode(value);
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) {
      crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

export function expectedUlPartNames(game) {
  const crc = usbExtremeCrc32(game.title).toString(16).toUpperCase().padStart(8, "0");
  const parts = [];
  for (let index = 0; index < game.parts; index++) {
    parts.push(`ul.${crc}.${game.rawStartup}.${index.toString(16).padStart(2, "0")}`);
  }
  return parts;
}
