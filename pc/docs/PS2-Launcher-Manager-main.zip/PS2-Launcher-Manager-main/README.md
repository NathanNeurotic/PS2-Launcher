# PS2 Launcher Manager https://irfanlesnar.github.io/PS2-Launcher-Manager/

A simple web-based tool to download and organize image assets for **PS2 Launcher**.

PS2 Launcher Manager scans the games on your USB drive, HDD, or other supported storage device and helps download the required artwork into the correct folders automatically.

## Features

- Automatically scans PS2 games from your disk
- Detects games inside `DVD` and `CD` folders
- Downloads artwork compatible with PS2 Launcher
- Automatically creates the required artwork folders
- Uses the correct game IDs and filenames
- No installation required
- Works directly from your web browser
- Useful for PS2 consoles without an internet connection

## How to Use

1. Connect your USB drive, HDD, or other PS2 game storage device to your computer.

2. Open **PS2 Launcher Manager** in your browser.

3. Click **Browse** and select the root folder of your storage device.

Example:

    USB/
    ├── DVD/
    │   ├── Game 1.iso
    │   └── Game 2.iso
    ├── CD/
    │   ├── Game 3.iso
    │   └── Game 4.iso
    └── ...

Select the root folder:

    USB/

Do not select the `DVD` or `CD` folder directly.

4. PS2 Launcher Manager will scan the `DVD` and `CD` folders and detect the games available on your drive.

5. The detected games will be displayed with their game information.

6. Select the artwork you want to download.

7. PS2 Launcher Manager will automatically create the required folders and download the images using filenames compatible with PS2 Launcher.

8. Once the download is complete, safely disconnect the storage device from your computer.

9. Connect the storage device back to your PS2 and open **PS2 Launcher**.

That's it. Your game artwork is ready to use.

## Why PS2 Launcher Manager?

Your PS2 does not need an internet connection to download game artwork.

You can prepare all required game images from your computer using PS2 Launcher Manager, then connect the drive back to your PS2.

This makes it easier to keep your PS2 Launcher game library clean and visually complete.

## Artwork Compatibility

PS2 Launcher Manager prepares artwork using the required filenames and folder structure expected by **PS2 Launcher**.

Artwork may include:

- Game covers
- Game logos

## License

The website source code is licensed under the **MIT License**.

Game cover artwork, logos, screenshots, backgrounds, and other game-related images included, processed, or distributed through this project remain the property of their respective copyright holders.

These third-party assets are **not covered by the MIT License**.

Artwork provided through this project may have been resized, renamed, converted, compressed, cropped, or otherwise adapted for compatibility with **PS2 Launcher**.

## Disclaimer

PS2 Launcher Manager is an independent community project.

It is not affiliated with, sponsored by, or endorsed by Sony Interactive Entertainment, PlayStation, or any game publisher.

All trademarks, game titles, logos, cover artwork, screenshots, and other copyrighted materials belong to their respective owners.

## Related Project

PS2 Launcher Manager is designed to work with **PS2 Launcher**.

Use it to prepare artwork on your computer and then use the generated files directly with PS2 Launcher on your PlayStation 2.
